import { AppRegistry } from 'react-native';

import huyaminiappdemoStreamer from './huyaminiappdemoStreamer/App';

AppRegistry.registerComponent('huyaminiappdemoStreamer', () => huyaminiappdemoStreamer);