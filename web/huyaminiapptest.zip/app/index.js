import { AppRegistry } from 'react-native';

import huyaminiappdemo from './huyaminiappdemo/App';

AppRegistry.registerComponent('huyaminiappdemo', () => huyaminiappdemo);